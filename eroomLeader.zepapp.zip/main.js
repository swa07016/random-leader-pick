/**
 * Copyright (c) 2022 ZEP Co., LTD
 */
App.onJoinPlayer.Add(function () {
  App.showCenterLabel(`조장을 뽑으려면 채팅에 LEADER를 입력하세요!`);
});
App.onSay.Add(function (player, text) {
  if (text == 'LEADER') {
    const players = App.players;
    const randomIndex = Math.floor(Math.random() * players.length);
    App.showCenterLabel(`우리의 조장은 ${players[randomIndex].name}!!`);

    for (let i = 0; i < players.length; i++) {
      if (i == randomIndex) {
        player.title = '😂';
      } else {
        player.title = '👏';
      }
    }

    setTimeout(function () {
      const players = App.players;
      players.forEach(function (player) {
        player.title = '';
      });
    }, 2500);
  }
});