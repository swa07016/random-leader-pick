/**
 * Copyright (c) 2022 ZEP Co., LTD
 */
App.onJoinPlayer.Add(function () {
  App.showCenterLabel(`조장을 뽑으려면 채팅에 LEADER를 입력하세요!`);
});
App.onSay.Add(function (player, text) {
  if (text == 'LEADER') {
    const players = App.players;
    const randomIndex = Math.floor(Math.random() * players.length);
    App.showCenterLabel(`우리의 조장은 ${players[randomIndex].name}!!`);
  }
});